=================================
Welcome to Jackrabbit JCR Client
=================================

This is the Jackrabbit JCR Client component of the Apache Jackrabbit project.

