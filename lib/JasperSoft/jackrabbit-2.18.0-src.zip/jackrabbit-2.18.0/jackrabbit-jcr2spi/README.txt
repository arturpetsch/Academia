=================================
Welcome to Jackrabbit JCR2SPI
=================================

This is the JCR2SPI component of the Apache Jackrabbit project.
This component contains an implementation of the JSR-170 API and
covers the functionality that is not delegated to the SPI implementation.
